package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import dto.MateriaPrimaDTO;

import modelo.MateriaPrimaModelo;

import utilidades.Msj;
import utilidades.Str;
import validacionesCampos.Valida;
import vista.CreacionMateriaPrimaVista;
import vista.MateriaPrimaVista;

public class ControladorCreacionMateriaPrima implements ActionListener {

	private CreacionMateriaPrimaVista vtCreacion;
	private MateriaPrimaModelo mdlMateriaPrima;
	private ControladorMateriaPrima ctrMateriaPrima;

	public ControladorCreacionMateriaPrima(ControladorMateriaPrima CtrMP,
			MateriaPrimaVista MPV) {
		this.vtCreacion = new CreacionMateriaPrimaVista(MPV);
		this.vtCreacion.getBtnCrear().addActionListener(this);
		this.vtCreacion.getBtnCancelar().addActionListener(this);

		this.mdlMateriaPrima = new MateriaPrimaModelo();
		this.ctrMateriaPrima = CtrMP;
	}

	public void Inicializar() {
		this.vtCreacion.Open();
	}

	private void CargarNuevaMateriaPrima() {
		CreacionMateriaPrimaVista vista = this.vtCreacion;
		String nombre = vista.getTxtMateriaprima().getText().trim();
		if (Valida.esNullOVacio(nombre)) {
			Msj.error("Error de creacion",
					"Debe ingresar un nombre para la materia prima");
		} else {
			// NO valido este porque siempre aparece uno marcado!
			String unidad = Str.trim(vista.getComboBox().getSelectedItem()); 
			MateriaPrimaDTO mt = new MateriaPrimaDTO(nombre, unidad); 
			this.mdlMateriaPrima.RegistrarMateriaPrima(mt);
			this.ctrMateriaPrima.ActualizarTabla();
			this.vtCreacion.Close();
		}
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == this.vtCreacion.getBtnCrear()) {
			this.CargarNuevaMateriaPrima();
			
		} else if (arg0.getSource() == this.vtCreacion.getBtnCancelar()) {
			this.vtCreacion.Close();
		}
	}
}