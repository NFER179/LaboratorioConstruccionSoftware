package daoImplementacion;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import conexion.ConectorDB;
import dao.MateriaPrimaDAO;
import dto.MateriaPrimaDTO;

public class MateriaPrimaImp implements MateriaPrimaDAO{

	private ConectorDB conector;
	
	public MateriaPrimaImp() {
		this.conector = ConectorDB.GetInstancia();
	}
	
	@Override
	public List<MateriaPrimaDTO> GetMateriasPrimas() {
		
		Statement stm = this.conector.GetStatement();
		String sqlString = "select * from materia_prima";
		ResultSet rs = null;
		List<MateriaPrimaDTO> materiasPrimas = new ArrayList<MateriaPrimaDTO>();
		
		try {
			rs = stm.executeQuery(sqlString);
			
			while (rs.next()) {
				materiasPrimas.add(new MateriaPrimaDTO(rs.getString("materia_prima"), rs.getString("unidad")));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		finally {
			this.conector.CloseConnection();
		}
		
		return materiasPrimas;
	}
	
	@Override
	public void InsertMateriaPrima(MateriaPrimaDTO MateriaPrima) {
		Statement stm = this.conector.GetStatement();
		String sqlString = "insert into materia_prima value('" + MateriaPrima.getNombre() + "', '" + MateriaPrima.getUnidad() + "')";
		
		try {
			stm.executeUpdate(sqlString);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}