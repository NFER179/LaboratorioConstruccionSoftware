package clasesImpresiones;

public class ObjSolicitudMP {

}
