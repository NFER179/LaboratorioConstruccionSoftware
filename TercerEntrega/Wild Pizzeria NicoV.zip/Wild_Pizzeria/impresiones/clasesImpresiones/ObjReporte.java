package clasesImpresiones;

import java.util.List;

import dto.ProductoEnVentaDTO;

public class ObjReporte {

	public String nombre;
	List<ProductoEnVentaDTO> productos;
	String fecha;
	double total;

}
