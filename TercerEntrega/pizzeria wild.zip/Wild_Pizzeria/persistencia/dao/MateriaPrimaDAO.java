package dao;

import java.util.List;

import dto.MateriaPrimaDTO;

public interface MateriaPrimaDAO {

	/* Obtener todas las materias primas existentes. */
	public List<MateriaPrimaDTO> GetMateriasPrimas();
	
	/* Inserta una nueva materia prima en la base de datos. */
	public void InsertMateriaPrima(MateriaPrimaDTO MateriaPrima);
}
