package clasesImpresiones;

import java.util.List;

import dto.ProductoEnVentaDTO;

public class ObjComanda {

	List<ProductoEnVentaDTO> listaProductos;
	String observaciones;
	String fecha;
	String hora;
	String nombre;

}
