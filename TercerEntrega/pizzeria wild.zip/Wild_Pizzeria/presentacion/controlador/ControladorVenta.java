package controlador;

import dto.VentaDTO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import modelo.VentaModelo;
import vista.VentasVista;
import controlador.Controlador;

public class ControladorVenta implements ActionListener {

	private VentasVista vtVenta;
	private Controlador controlador;
	private VentaModelo mdlVenta;
	private List<VentaDTO> ventasEnTabla;
	private ControladorVentasCocina ctrVentasCocina;

	public ControladorVenta(Controlador controlador) {
		this.vtVenta = new VentasVista();
		this.vtVenta.GetBtnEnviar().addActionListener(this);
		this.vtVenta.GetBtnEnViaje().addActionListener(this);
		this.vtVenta.GetBtnModificar().addActionListener(this);
		this.vtVenta.GetBtnEnMostrador().addActionListener(this);
		this.vtVenta.GetBtnNuevaVenta().addActionListener(this);
		this.vtVenta.GetBtnCancelarVenta().addActionListener(this);
		this.vtVenta.GetBtnVentaEntregada().addActionListener(this);
		this.vtVenta.GetBtnVolverInicio().addActionListener(this);

		this.controlador = controlador;
		this.mdlVenta = new VentaModelo();
		this.ventasEnTabla = null;
		this.ctrVentasCocina = ControladorVentasCocina.GetInstancia();
	}

	public void Inicializar() {
		this.llenarTabla();
		this.vtVenta.Open();
	}

	private String Delivery(boolean arg0) {
		if (arg0)
			return "Si";
		else
			return "No";
	}

	private void llenarTabla() {
		this.vtVenta.GetModelVenta().setRowCount(0); // Vacia la tabla
		this.vtVenta.GetModelVenta().setColumnCount(0);
		this.vtVenta.GetModelVenta().setColumnIdentifiers(
				this.vtVenta.GetNombreColumnas());
		this.ventasEnTabla = this.mdlVenta.GetVentaSinFacturar();
		for (VentaDTO p : this.ventasEnTabla) {
			Object[] fila = { p.getFecha(), Integer.toString(p.getNumVenta()),
					p.getCliente(), Integer.toString(p.getPrecio()) + " $",
					p.getEstado(), this.Delivery(p.isDelivery()) };
			this.vtVenta.GetModelVenta().addRow(fila);
		}
		this.vtVenta.GetTable().setModel(this.vtVenta.GetModelVenta());
	}

	public void RecargarTabla() {
		this.llenarTabla();
	}

//	private String toString(Boolean arg0) {
//		if (arg0 == true)
//			return "Y";
//		else
//			return "F";
//	}

	private void CancelarVentas(List<VentaDTO> Ventas) {
		// int[] SelectedRows = this.pedido.GetTable().getSelectedRows();
		//
		// for (int i = 0 ; i < SelectedRows.length ; i++) {
		// this.mdlPedido.cancelarPedido(Integer.parseInt((String)this.pedido.GetTable().getValueAt(SelectedRows[i],
		// 0)));
		// }

		for (VentaDTO venta : Ventas) {
			this.mdlVenta.CancelarVenta(venta.getFecha(), venta.getNumVenta());
		}
		this.llenarTabla();
	}

	private void FinalizarVentas(List<VentaDTO> Ventas) {
		// int[] SelectedRows = this.pedido.GetTable().getSelectedRows();
		//
		// for ( int i = 0 ; i < SelectedRows.length ; i++ ) {
		// this.mdlPedido.FinalizarPedido(Integer.parseInt(this.pedido.GetTable().getValueAt(SelectedRows[i],
		// 0).toString()));
		// }

		for (VentaDTO venta : Ventas) {
			this.mdlVenta.FinalizarVenta(venta.getFecha(), venta.getNumVenta());
		}
		this.llenarTabla();
	}

	private void VentasEnMostrador(List<VentaDTO> Ventas) {
		// int[] SelectedRows = this.pedido.GetTable().getSelectedRows();
		//
		// for (int i = 0 ; i < SelectedRows.length ; i++ ) {
		// this.mdlPedido.PedidoArmado(Integer.parseInt(this.pedido.GetTable().getValueAt(SelectedRows[i],
		// 0).toString()));
		// }

		for (VentaDTO venta : Ventas) {
			this.mdlVenta.VentaArmado(venta.getFecha(), venta.getNumVenta());
		}
		this.llenarTabla();
	}

	private List<VentaDTO> GetVentasSeleccionadas() {
		List<VentaDTO> ventas = new ArrayList<VentaDTO>();
		int[] SelectedRows = this.vtVenta.GetTable().getSelectedRows();

		for (int i = 0; i < SelectedRows.length; i++) {
			JTable table = this.vtVenta.GetTable();
			ventas.add(this.mdlVenta.GetVenta(table.getValueAt(SelectedRows[i], 0).toString().trim(), Integer.parseInt(table.getValueAt(SelectedRows[i], 1).toString().trim())));
		}
		return ventas;
	}

	private boolean NoHayVentasEnViaje(List<VentaDTO> Ventas) {
		boolean NoViajes = true;
		for (VentaDTO venta : Ventas) {
			if (venta.getEstado().toUpperCase().equals("VIAJE")) {
				NoViajes = false;
			}
		}
		return NoViajes;
	}

	private boolean SinVentasPendientes(List<VentaDTO> Ventas) {
		boolean sinPendientes = true;
		for (VentaDTO venta : Ventas) {
			if (!venta.getEstado().toUpperCase().equals("PENDIENTE")) {
				sinPendientes = false;
			}
		}
		return sinPendientes;
	}

	private boolean VentasDelivery(List<VentaDTO> Ventas) {
		boolean ventasDelivery = true;
		for (VentaDTO venta : Ventas) {
			if (!venta.isDelivery()) {
				ventasDelivery = false;
			}
		}
		return ventasDelivery;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		/*Boton para enviar la venta a domicilio.*/
		if (arg0.getSource() == this.vtVenta.GetBtnEnviar()) {
			List<VentaDTO> lventa = this.GetVentasSeleccionadas();
			if (lventa.size() > 0) {
				if (VentasDelivery(lventa)) {
					if (this.NoHayVentasEnViaje(lventa)) {
						ControladorAsignacionRepartidor ctrAsignarRepartidor = new ControladorAsignacionRepartidor(
								this, this.vtVenta, lventa);
						ctrAsignarRepartidor.Inicializar();
						this.ctrVentasCocina.RecargarTablas();

					} else {
						JOptionPane.showMessageDialog(null,
								"No puede Asigar Ventas en Estado 'Viaje'",
								"Error Estado Ventas",
								JOptionPane.ERROR_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(null,
							"No puede Asignar Ventas que no Sean a Domicilio.",
							"Error de delivery", JOptionPane.ERROR_MESSAGE);
				}
			} else {
				JOptionPane.showMessageDialog(null,
						"Debe Seleccionar al Menos una Venta.",
						"Error Seleccion Venta", JOptionPane.ERROR_MESSAGE);
			}
		/* Boton para ver las ventas que estan en viaje. */
		} else if (arg0.getSource() == this.vtVenta.GetBtnEnViaje()) {
			ControladorVentasEnViaje ctrVentasEnViaje = new ControladorVentasEnViaje(
					this, this.vtVenta);
			ctrVentasEnViaje.Iniciar();
		/* Boton para asignar las ventas que estan en el mostrador. */
		} else if (arg0.getSource() == this.vtVenta.GetBtnEnMostrador()) {
			List<VentaDTO> ventas = this.GetVentasSeleccionadas();
			if (this.NoHayVentasEnViaje(ventas)) {
				this.VentasEnMostrador(ventas);
				this.ctrVentasCocina.RecargarTablas();
			} else {
				JOptionPane
						.showMessageDialog(
								null,
								"No Puede Usar esta Funcionalidad Para Ventas que esten en Viaje",
								"Error Seleccion de Ventas",
								JOptionPane.ERROR_MESSAGE);
			}
		/* Boton para poder modificar una venta. */
		} else if (arg0.getSource() == this.vtVenta.GetBtnModificar()) {

			if (this.vtVenta.GetTable().getSelectedRow() >= 0 && this.vtVenta.GetTable().getSelectedRows().length == 1) {
				List<VentaDTO> ventas = this.GetVentasSeleccionadas();
				if (this.NoHayVentasEnViaje(ventas)) {
					if (SinVentasPendientes(ventas)) {
						JTable t = this.vtVenta.GetTable();
						String fecha = t.getValueAt(t.getSelectedRow(), 0).toString().trim();
						int numVenta = Integer.parseInt(t.getValueAt(t.getSelectedRow(), 1).toString().trim());
						ControladorArmadoVenta ctrArmadoVenta = new ControladorArmadoVenta(	this, this.vtVenta, fecha, numVenta);
						ctrArmadoVenta.Inicializar();
					} else {
						JOptionPane.showMessageDialog(null,
								"No se pueden modificar las Ventas Armadas.",
								"Error Estado Ventas",
								JOptionPane.ERROR_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(null,
							"No Puede Modificar Ventas que Esten en Viaje",
							"Error de Modificaci�n", JOptionPane.ERROR_MESSAGE);
				}
			} else {
				JOptionPane.showMessageDialog(null,
						"Debe Seleccionar una Unica Venta.");
			}
		/* Boton para generar una nueva venta. */
		} else if (arg0.getSource() == this.vtVenta.GetBtnNuevaVenta()) {
			ControladorArmadoVenta ctrArmadoVenta = new ControladorArmadoVenta(
					this, this.vtVenta);
			ctrArmadoVenta.Inicializar();
		/* Boton para cancelar las ventas. */
		} else if (arg0.getSource() == this.vtVenta.GetBtnCancelarVenta()) {
			List<VentaDTO> ventas = this.GetVentasSeleccionadas();
			if (this.NoHayVentasEnViaje(ventas)) {
				this.CancelarVentas(ventas);
				this.ctrVentasCocina.RecargarTablas();
			} else {
				JOptionPane.showMessageDialog(null,
						"No Puede Cancelar Ventas que Estan en Viaje",
						"Error Cancelaci�n", JOptionPane.ERROR_MESSAGE);
			}
		/* Boton para indicar que las ventas fueron entregas(solo por mostrador). */
		} else if (arg0.getSource() == this.vtVenta.GetBtnVentaEntregada()) {
			List<VentaDTO> ventas = this.GetVentasSeleccionadas();
			if (this.NoHayVentasEnViaje(ventas)) {
				this.FinalizarVentas(ventas);
				this.ctrVentasCocina.RecargarTablas();
			} else {
				JOptionPane
						.showMessageDialog(
								null,
								"Las Ventas que Estan en Viaje no Pueden Entregarse por Mostrador.",
								"Error en Entregar Venta",
								JOptionPane.ERROR_MESSAGE);
			}
		/* Boton para volver al men� de inicio. */
		} else if (arg0.getSource() == this.vtVenta.GetBtnVolverInicio()) {
			this.controlador.Inicializar();
			this.vtVenta.Close();
		}
	}
}