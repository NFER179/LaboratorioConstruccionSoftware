package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import dto.DeliveryDTO;
import dto.DeliveryVentaDTO;
import dto.VentaDTO;
import modelo.DeliveryModelo;
import modelo.DeliveryVentaModelo;
import modelo.VentaModelo;
import vista.VentasEnViajeVista;

public class ControladorVentasEnViaje implements ActionListener{

	private VentasEnViajeVista vtVentasEnViaje;
	private VentaModelo mdlVenta;
	private ControladorVenta ctrVenta;
	private DeliveryModelo mdlDelivery;
	private String fechadeliverySeleccionado;
	private int numPedidoSeleccionado;
	private DeliveryVentaModelo mdlDeliveryVenta;
	
	public ControladorVentasEnViaje(ControladorVenta CtrVenta, JFrame Frame) {
		this.vtVentasEnViaje = new VentasEnViajeVista(Frame);
		this.vtVentasEnViaje.getBtnSeleccionardelivery().addActionListener(this);
		this.vtVentasEnViaje.getBtnEntregado().addActionListener(this);
		this.vtVentasEnViaje.getBtnNoEntregado().addActionListener(this);
		this.vtVentasEnViaje.getBtnAceptar().addActionListener(this);
		
		this.mdlVenta = new VentaModelo();
		this.ctrVenta = CtrVenta;
		this.mdlDelivery = new DeliveryModelo();
		this.mdlDeliveryVenta = new DeliveryVentaModelo();
	}
	
	public void Iniciar() {
		this.CargarTablaDelivery();
		this.vtVentasEnViaje.Open();
	}
	
	private void CargarTablaDelivery() {
		/* Carga la tabla de delivery. */
		this.vtVentasEnViaje.getModelTableDelivery().setRowCount(0);
		this.vtVentasEnViaje.getModelTableDelivery().setColumnCount(0);
		this.vtVentasEnViaje.getModelTableDelivery().setColumnIdentifiers(this.vtVentasEnViaje.getNombreColumnasDelivery());
		for (DeliveryDTO delivery:this.mdlDelivery.DeliverysEnViaje()) {
			Object[] fila = {delivery.getFecha(), Integer.toString(delivery.getNumDelivery())};
			this.vtVentasEnViaje.getModelTableDelivery().addRow(fila);
		}
		this.vtVentasEnViaje.getTableDelivery().setModel(this.vtVentasEnViaje.getModelTableDelivery());
	}
	
	private List<VentaDTO> VentasSeleccionadas() {
		List<VentaDTO> ventas = new ArrayList<VentaDTO>();
		int[] SelectedRows = this.vtVentasEnViaje.getTableVentas().getSelectedRows();
		
		for(int i = 0; i < SelectedRows.length; i++) {
			JTable table = this.vtVentasEnViaje.getTableVentas();
			ventas.add(this.mdlVenta.GetVenta(table.getValueAt(SelectedRows[i], 0).toString().trim(),
					Integer.parseInt(table.getValueAt(SelectedRows[i], 1).toString().trim())));
		}
		return ventas;
	}
	
	private void VentasEntregados(List<VentaDTO> Ventas) {
		for (VentaDTO venta:Ventas) {
			this.mdlDelivery.DeliverysEntregados(this.fechadeliverySeleccionado, this.numPedidoSeleccionado, venta);
			this.mdlVenta.FinalizarVenta(venta.getFecha(), venta.getNumVenta());
		}
		this.CargarTablaDelivery();
	}
	
	private void VentaNoEntregada(VentaDTO Venta, String Observacion) {
		this.mdlDeliveryVenta.VentaNoEntregada(this.fechadeliverySeleccionado, this.numPedidoSeleccionado, Venta, Observacion);
		this.mdlVenta.VentaArmado(Venta.getFecha(), Venta.getNumVenta());

		this.CargarTablaDelivery();
	}
	
	private void CargarDeliverySeleccionado() {
		int FilaSeleccionada = this.vtVentasEnViaje.getTableDelivery().getSelectedRow();
		this.fechadeliverySeleccionado = this.vtVentasEnViaje.getTableDelivery().getValueAt(FilaSeleccionada, 0).toString().trim();
		this.numPedidoSeleccionado = Integer.parseInt(this.vtVentasEnViaje.getTableDelivery().getValueAt(FilaSeleccionada, 1).toString().trim());
	}
	
	private void CargarTablaVentas() {
		this.vtVentasEnViaje.getModelTableVentas().setRowCount(0);
		this.vtVentasEnViaje.getModelTableVentas().setColumnCount(0);
		this.vtVentasEnViaje.getModelTableVentas().setColumnIdentifiers(this.vtVentasEnViaje.getNombreColumnasVentas());
		for(DeliveryVentaDTO dv:this.mdlDeliveryVenta.GetVentasPara(this.fechadeliverySeleccionado, this.numPedidoSeleccionado)) {
			Object[] fila = {dv.getFechaVenta(), Integer.toString(dv.getNumVenta())};
			this.vtVentasEnViaje.getModelTableVentas().addRow(fila);
		}
		this.vtVentasEnViaje.getTableVentas().setModel(this.vtVentasEnViaje.getModelTableVentas());
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(arg0.getSource() == this.vtVentasEnViaje.getBtnSeleccionardelivery()) {
			if(this.vtVentasEnViaje.getTableDelivery().getSelectedRows().length >= 1) {
				this.CargarDeliverySeleccionado();
				this.CargarTablaVentas();
			}
		}
		else if (arg0.getSource() == this.vtVentasEnViaje.getBtnEntregado()) {
			List<VentaDTO> ventas = this.VentasSeleccionadas(); 
			if (ventas.size() > 0) {
				this.VentasEntregados(ventas);
				this.CargarTablaVentas();
			}
			else {
				JOptionPane.showMessageDialog(null, "Debe Seleccionar al Menos una Venta", "Error Seleccion Venta", JOptionPane.ERROR_MESSAGE);
			}
		}
		else if(arg0.getSource() == this.vtVentasEnViaje.getBtnNoEntregado()) {
			int[] Seleccionadas = this.vtVentasEnViaje.getTableVentas().getSelectedRows();
			if(Seleccionadas.length == 1) {
				String obs = JOptionPane.showInputDialog(null);	
				JTable table = this.vtVentasEnViaje.getTableVentas();
				String fecha = table.getValueAt(Seleccionadas[0], 0).toString().trim();
				int numVenta = Integer.parseInt(table.getValueAt(Seleccionadas[0], 1).toString().trim());
				this.VentaNoEntregada(this.mdlVenta.GetVenta(fecha, numVenta), obs);
				this.CargarTablaVentas();
			}
			else {
				JOptionPane.showMessageDialog(null, "Solo Puede Cancelar de a una Venta.", "Error Seleccion Venta.", JOptionPane.ERROR_MESSAGE);
			}
		}
		else if(arg0.getSource() == this.vtVentasEnViaje.getBtnAceptar()) {
			this.ctrVenta.Inicializar();
			this.vtVentasEnViaje.Close();
		}
	}
}