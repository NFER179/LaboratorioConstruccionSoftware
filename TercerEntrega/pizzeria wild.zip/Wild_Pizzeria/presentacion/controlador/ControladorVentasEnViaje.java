package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;

import dto.VentaDTO;

import modelo.VentaModelo;
import modelo.RepartidorModelo;

import vista.VentasEnViajeVista;

public class ControladorVentasEnViaje implements ActionListener{

	private VentasEnViajeVista vtVentasEnViaje;
	private VentaModelo mdlVenta;
	private ControladorVenta ctrVenta;
	private RepartidorModelo mdlRepartidor;
	
	public ControladorVentasEnViaje(ControladorVenta CtrVenta, JFrame Frame) {
		this.vtVentasEnViaje = new VentasEnViajeVista(Frame);
		this.vtVentasEnViaje.getBtnEntregado().addActionListener(this);
		this.vtVentasEnViaje.getBtnNoEntregado().addActionListener(this);
		this.vtVentasEnViaje.getBtnAceptar().addActionListener(this);
		
		this.mdlVenta = new VentaModelo();
		this.ctrVenta = CtrVenta;
		this.mdlRepartidor = new RepartidorModelo();
	}
	
	public void Iniciar() {
		this.CargarTabla();
		this.vtVentasEnViaje.Open();
	}
	
	private void CargarTabla() {
		this.vtVentasEnViaje.getModelTable().setRowCount(0);
		this.vtVentasEnViaje.getModelTable().setColumnCount(0);
		this.vtVentasEnViaje.getModelTable().setColumnIdentifiers(this.vtVentasEnViaje.getNombreColumnas());
		for (VentaDTO venta:this.mdlVenta.GetVentasEnViaje()) {
			Object[] fila = {Integer.toString(venta.getNumVenta())};
			this.vtVentasEnViaje.getModelTable().addRow(fila);
		}
		this.vtVentasEnViaje.getTable().setModel(this.vtVentasEnViaje.getModelTable());
	}
	
	private List<VentaDTO> VentasSeleccionados() {
		List<VentaDTO> ventas = new ArrayList<VentaDTO>();
		int[] SelectedRows = this.vtVentasEnViaje.getTable().getSelectedRows();
		
		for(int i = 0; i < SelectedRows.length; i++) {
			JTable table = this.vtVentasEnViaje.getTable();
			ventas.add(this.mdlVenta.GetVenta(table.getValueAt(SelectedRows[i], 0).toString().trim(),
					Integer.parseInt(table.getValueAt(SelectedRows[i], 1).toString().trim())));
		}
		return ventas;
	}
	
	private void VentasEntregados(List<VentaDTO> Ventas) {
		for (VentaDTO venta:Ventas) {
			this.mdlVenta.FinalizarVenta(venta.getFecha(), venta.getNumVenta());
		}
		
		this.CargarTabla();
	}
	
	private void VentasNoEntregadas(List<VentaDTO> Ventas) {
		for (VentaDTO venta:Ventas) {
			this.mdlVenta.VentaArmado(venta.getFecha(), venta.getNumVenta());
			this.mdlRepartidor.DesasignarVenta(venta.getNumVenta());
		}
		
		this.CargarTabla();
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == this.vtVentasEnViaje.getBtnEntregado()) {
			List<VentaDTO> ventas = this.VentasSeleccionados(); 
			if (ventas.size() > 0) {
				this.VentasEntregados(ventas);
			}
			else {
				JOptionPane.showMessageDialog(null, "Debe Seleccionar al Menos una Venta", "Error Seleccion Venta", JOptionPane.ERROR_MESSAGE);
			}
		}
		else if(arg0.getSource() == this.vtVentasEnViaje.getBtnNoEntregado()) {
			List<VentaDTO> ventas = this.VentasSeleccionados();
			if(ventas.size() > 0) {
				this.VentasNoEntregadas(ventas);
			}
			else {
				JOptionPane.showMessageDialog(null, "Debe Seleccionar al Menos un Venta.", "Error Seleccion Venta.", JOptionPane.ERROR_MESSAGE);
			}
		}
		else if(arg0.getSource() == this.vtVentasEnViaje.getBtnAceptar()) {
			this.ctrVenta.Inicializar();
			this.vtVentasEnViaje.Close();
		}
	}
}