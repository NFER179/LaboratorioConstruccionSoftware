/** Nicolas Daniel Fernandez, 29/09/2015 - Creacion de la clase. **/
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import clasesImpresiones.ImpresionDocx;

import modelo.VentaModelo;
import modelo.RepartidorModelo;

import dto.VentaDTO;
import dto.RepartidorDTO;

import vista.AsignacionRepartidoresVista;

public class ControladorAsignacionRepartidor implements ActionListener {

	private AsignacionRepartidoresVista vtAsignacionRepartidores;
	private ControladorVenta ctrPedido;
	private List<VentaDTO> lPedidos;
	private RepartidorModelo mdlRepartidor;
	private VentaModelo mdlPedido;

	public ControladorAsignacionRepartidor(ControladorVenta ControladorPedido,
			JFrame Frame, List<VentaDTO> LPedido) {
		this.vtAsignacionRepartidores = new AsignacionRepartidoresVista(Frame);
		this.vtAsignacionRepartidores.getBtnBuscarrepartidor()
				.addActionListener(this);
		this.vtAsignacionRepartidores.getBtnAsignar().addActionListener(this);
		this.vtAsignacionRepartidores.getBtnCancelar().addActionListener(this);

		this.ctrPedido = ControladorPedido;
		this.lPedidos = LPedido;
		this.mdlRepartidor = new RepartidorModelo();
		this.mdlPedido = new VentaModelo();
	}

	public void Inicializar() {
		this.CargarTabla();
		this.vtAsignacionRepartidores.Open();
	}

	private void CargarTabla() {
		this.vtAsignacionRepartidores.getModelTable().setRowCount(0);
		this.vtAsignacionRepartidores.getModelTable().setColumnCount(0);
		this.vtAsignacionRepartidores.getModelTable().setColumnIdentifiers(
				this.vtAsignacionRepartidores.getNombreColumnas());
		for (VentaDTO p : this.lPedidos) {
			Object[] fila = { Integer.toString(p.getNumVenta()),
					p.getDireccion() };
			this.vtAsignacionRepartidores.getModelTable().addRow(fila);
		}
		this.vtAsignacionRepartidores.getTable().setModel(
				this.vtAsignacionRepartidores.getModelTable());
	}

	public void CargarRepartidor(RepartidorDTO Repartidor) {
		this.vtAsignacionRepartidores.getTxtRepartidor().setText(
				Integer.toString(Repartidor.getRepartidorId()));
		this.vtAsignacionRepartidores.getTxtNombrerepartidor().setText(
				Repartidor.getApellido() + " " + Repartidor.getNombre());
	}

	private List<String> ListaDireccones() {
		List<String> direcciones = new ArrayList<String>();
		for (VentaDTO pedido : this.lPedidos) {
			direcciones.add(pedido.getDireccion());
		}

		return direcciones;
	}

	private String FechaDelDia() {
		String fecha = "";
		Calendar c = Calendar.getInstance();
		fecha = fecha + c.get(Calendar.YEAR) + "-";
		fecha = fecha + c.get(Calendar.MONTH) + "-";
		fecha = fecha + c.get(Calendar.DATE) + " ";
		fecha = fecha + c.get(Calendar.HOUR) + "_";
		fecha = fecha + c.get(Calendar.MINUTE);

		return fecha;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		Object source = arg0.getSource();
		if (source == this.vtAsignacionRepartidores.getBtnBuscarrepartidor()) {
			accionRepartidorBusqueda();
		} else if (source == this.vtAsignacionRepartidores.getBtnAsignar()) {
			accionRepartidorAsignar();
		} else if (source == this.vtAsignacionRepartidores.getBtnCancelar()) {
			accionRepartidorCancelar();
		} else {
			System.out.println("ESTADO ILEGAL");
		}
	}

	private void accionRepartidorBusqueda() {
		ControladorBuscadorRepartidor ctrBuscadorRepartidor = new ControladorBuscadorRepartidor(
				this, this.vtAsignacionRepartidores);
		ctrBuscadorRepartidor.Inicializar();
	}

	private void accionRepartidorCancelar() {
		this.ctrPedido.Inicializar();
		this.vtAsignacionRepartidores.Close();
	}

	private void accionRepartidorAsignar() {
		String textoRepartidor = this.vtAsignacionRepartidores
				.getTxtRepartidor().getText();
		if (!textoRepartidor.equals(null)) {
			textoRepartidor = textoRepartidor.trim();

			if (textoRepartidor != "") {
				System.out.println(textoRepartidor);
				this.mdlRepartidor.AsignarPedidos(
						Integer.parseInt(textoRepartidor), this.lPedidos);
			} else {
				JOptionPane.showMessageDialog(null,
						"Debe seleccionar a un repartidor");
			}
			this.mdlPedido.VentasEnViaje(this.lPedidos);
			this.ctrPedido.RecargarTabla();
			ImpresionDocx impresion = new ImpresionDocx();
			impresion.ImprimirDirecciones(this.FechaDelDia()
					+ " - "
					+ this.vtAsignacionRepartidores.getTxtNombrerepartidor()
							.getText() + "Direcciones", this.ListaDireccones());
			this.vtAsignacionRepartidores.Close();
		}
	}
}