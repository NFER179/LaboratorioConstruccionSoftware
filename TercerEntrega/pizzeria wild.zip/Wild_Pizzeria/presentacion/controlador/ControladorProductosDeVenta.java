package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import validacionesCampos.ValidacionCampos;
import vista.ProductosDeVentasVista;
import dto.SaborDTO;
import modelo.*;

public class ControladorProductosDeVenta implements ActionListener {

	private ProductosDeVentasVista vtProPe;
	private List<SaborDTO> lstProducto;
	private SaborModelo mdlSabor;
	private ProductoModelo mdlProducto;
	private ControladorArmadoVenta ctrAP;

	public ControladorProductosDeVenta(ControladorArmadoVenta CtrAP,
			JDialog Dialog) {
		this.vtProPe = new ProductosDeVentasVista(Dialog);
		this.vtProPe.getBtnBusqueda().addActionListener(this);
		this.vtProPe.getBtnAceptar().addActionListener(this);
		this.vtProPe.getBtnCancelar().addActionListener(this);

		this.ctrAP = CtrAP;

		this.mdlSabor = new SaborModelo();
		this.mdlProducto = new ProductoModelo();
	}

	public void Iniciar() {
		this.vtProPe.Open();
	}

	public void CargarProducto(String Producto) {
		this.vtProPe.getTxtIdproducto().setText(Producto);
		this.vtProPe.getTxtDescrProducto().setText(
				this.mdlProducto.GetDescr(Producto));
	}

	public void ActualizarTabla() {
		this.vtProPe.getModelSabores().setRowCount(0);
		this.vtProPe.getModelSabores().setColumnCount(0);
		this.vtProPe.getModelSabores().setColumnIdentifiers(
				this.vtProPe.getNombreColunmnas());
		this.lstProducto = this.mdlSabor.GetSabores(this.vtProPe
				.getTxtIdproducto().getText());
		for (SaborDTO sabor : this.lstProducto) {
			Object[] fila = { sabor.getNombre(), sabor.getPrecio() };
			this.vtProPe.getModelSabores().addRow(fila);
		}
		this.vtProPe.getTable().setModel(this.vtProPe.getModelSabores());
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == this.vtProPe.getBtnBusqueda()) {
			ControladorProductoBusqueda cpb = new ControladorProductoBusqueda(
					this, this.vtProPe);
			cpb.Iniciar();
		} else if (arg0.getSource() == this.vtProPe.getBtnAceptar()) {
			/* Si selccciona una fila y pone un cantidad */
			if (!this.vtProPe.getTxtIdproducto().getText().trim().equals("")){
				if (this.vtProPe.getTable().getSelectedRow() >= 0) {
					if (this.vtProPe.getTxtCantidad().getText().trim().length() > 0) {
						if (ValidacionCampos.positiveIntegerValid(vtProPe.getTxtCantidad().getText())) {
							this.ctrAP.AgregarProducto(this.vtProPe.getTxtIdproducto().getText(),this.vtProPe.getTable().getValueAt(this.vtProPe.getTable().getSelectedRow(), 0).toString(), Integer.parseInt(this.vtProPe.getTxtCantidad().getText()));
							this.vtProPe.Close();
						}
						else {
							JOptionPane.showMessageDialog(null, "Debe Ingresar una cantidad valida", "Error Formato Cantidad", JOptionPane.ERROR_MESSAGE);
						}
					}
					else {
						JOptionPane.showMessageDialog(null, "Debe ingresar una cantidad.", "Error Cantidad", JOptionPane.WARNING_MESSAGE);
					}
				}
				else {
					JOptionPane.showMessageDialog(null, "Debe seleccionar sabor.", "Error seleccion sabor", JOptionPane.WARNING_MESSAGE);
				}
			}
			else{
				JOptionPane.showMessageDialog(null, "Debe seleccionar un producto.", "Error de seleccion de producto.", JOptionPane.INFORMATION_MESSAGE);
			}
		} else if (arg0.getSource() == this.vtProPe.getBtnCancelar()) {
				this.vtProPe.Close();
			}
		}
	}