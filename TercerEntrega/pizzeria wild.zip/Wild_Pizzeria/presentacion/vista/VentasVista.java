package vista;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import validacionObjetosVista.WDefaultTableModel;
import validacionObjetosVista.WTable;

public class VentasVista extends JFrame {
	
	private JPanel contentPane;
	private JTable tableVentas;
	private DefaultTableModel modelVentas;
	private String[] nombreColumnas = {"Fecha", "N� Venta", "Cliente", "Valor a Cobrar", "Estado", "A Domicilio"};
	private JButton btnNuevaVenta;
	private JButton btnCancelarVenta;
	private JButton btnVentaEntregada;
	private JButton btnEnviar;
	private JButton btnEnViaje;
	private JButton btnEnMostrador;
	private JButton btnInformacin;
	private JButton btnModificar;
	private JButton btnVolverInicio;

	public VentasVista() {
		
		this.setResizable(false);
		this.setTitle("Ventas");
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.setBounds(100, 100, 702, 405);
		
		this.contentPane = new JPanel();
		this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		this.setContentPane(contentPane);
		this.contentPane.setLayout(null);
		this.setLocationRelativeTo(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 526, 315);
		this.contentPane.add(scrollPane);
		
		this.modelVentas = new WDefaultTableModel(null,this.nombreColumnas);
		this.tableVentas = new WTable(this.modelVentas);
		scrollPane.setViewportView(tableVentas);
		
		this.btnNuevaVenta = new JButton("Nueva Venta");
		this.btnNuevaVenta.setBounds(10, 337, 140, 23);
		
		this.contentPane.add(btnNuevaVenta);
		
		this.btnCancelarVenta = new JButton("Cancelar Venta");
		this.btnCancelarVenta.setBounds(160, 337, 140, 23);
		this.contentPane.add(btnCancelarVenta);
		
		this.btnVentaEntregada = new JButton("Venta Entregada");
		this.btnVentaEntregada.setBounds(310, 337, 140, 23);
		this.contentPane.add(btnVentaEntregada);
		
		this.btnEnviar = new JButton("Enviar");
		this.btnEnviar.setBounds(546, 8, 140, 23);
		this.contentPane.add(btnEnviar);
		
		this.btnEnViaje = new JButton("En Viaje");
		this.btnEnViaje.setBounds(546, 42, 140, 23);
		this.contentPane.add(btnEnViaje);
		
		this.btnEnMostrador = new JButton("En mostrador");
		this.btnEnMostrador.setBounds(546, 76, 140, 23);
		this.contentPane.add(btnEnMostrador);
		
		this.btnInformacin = new JButton("Informaci\u00F3n");
		this.btnInformacin.setBounds(546, 110, 140, 23);
		this.contentPane.add(btnInformacin);
		
		this.btnModificar = new JButton("Modificar");
		this.btnModificar.setBounds(546, 144, 140, 23);
		this.contentPane.add(btnModificar);
		
		this.btnVolverInicio = new JButton("Volver Inicio");
		this.btnVolverInicio.setBounds(460, 337, 140, 23);
		this.contentPane.add(btnVolverInicio);
	}
	
	public void Open() {
		this.setVisible(true);
	}
	
	public void Close() {
		this.setVisible(false);
	}

	public JTable GetTable() {
		return this.tableVentas;
	}
	
	public DefaultTableModel GetModelVenta() {
		return this.modelVentas;
	}
	
	public String[] GetNombreColumnas() {
		return this.nombreColumnas;
	}
	
	public JButton GetBtnNuevaVenta() {
		return this.btnNuevaVenta;
	}
	
	public JButton GetBtnCancelarVenta() {
		return this.btnCancelarVenta;
	}
	
	public JButton GetBtnVentaEntregada() {
		return this.btnVentaEntregada;
	}
	
	public JButton GetBtnEnviar() {
		return this.btnEnviar;
	}
	
	public JButton GetBtnEnViaje() {
		return this.btnEnViaje;
	}
	
	public JButton GetBtnEnMostrador() {
		return this.btnEnMostrador;
	}

	public JButton GetBtnModificar() {
		return this.btnModificar;
	}
	
	public JButton GetBtnInformacin() {
		return this.btnInformacin;
	}
	
	public JButton GetBtnVolverInicio() {
		return this.btnVolverInicio;
	}
}