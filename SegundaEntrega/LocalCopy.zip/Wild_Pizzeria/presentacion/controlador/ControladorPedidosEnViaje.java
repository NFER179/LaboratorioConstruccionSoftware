package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import dto.PedidoDTO;

import modelo.PedidoModelo;
import modelo.RepartidorModelo;

import vista.PedidosEnViajeVista;

public class ControladorPedidosEnViaje implements ActionListener{

	private PedidosEnViajeVista vtPedidosEnViaje;
	private PedidoModelo mdlPedido;
	private ControladorPedido ctrPedido;
	private RepartidorModelo mdlRepartidor;
	
	public ControladorPedidosEnViaje(ControladorPedido CtrPedido, JFrame Frame) {
		this.vtPedidosEnViaje = new PedidosEnViajeVista(Frame);
		this.vtPedidosEnViaje.getBtnEntregado().addActionListener(this);
		this.vtPedidosEnViaje.getBtnNoEntregado().addActionListener(this);
		this.vtPedidosEnViaje.getBtnAceptar().addActionListener(this);
		
		this.mdlPedido = new PedidoModelo();
		this.ctrPedido = CtrPedido;
		this.mdlRepartidor = new RepartidorModelo();
	}
	
	public void Iniciar() {
		this.CargarTabla();
		this.vtPedidosEnViaje.Open();
	}
	
	private void CargarTabla() {
		this.vtPedidosEnViaje.getModelTable().setRowCount(0);
		this.vtPedidosEnViaje.getModelTable().setColumnCount(0);
		this.vtPedidosEnViaje.getModelTable().setColumnIdentifiers(this.vtPedidosEnViaje.getNombreColumnas());
		for (PedidoDTO pedido:this.mdlPedido.GetPedidosEnViaje()) {
			Object[] fila = {Integer.toString(pedido.getNumPedido())};
			this.vtPedidosEnViaje.getModelTable().addRow(fila);
		}
		this.vtPedidosEnViaje.getTable().setModel(this.vtPedidosEnViaje.getModelTable());
	}
	
	private List<PedidoDTO> PedidosSeleccionados() {
		List<PedidoDTO> pedidos = new ArrayList<PedidoDTO>();
		int[] SelectedRows = this.vtPedidosEnViaje.getTable().getSelectedRows();
		
		for(int i = 0; i < SelectedRows.length; i++) {
			pedidos.add(this.mdlPedido.GetPedido(Integer.parseInt(this.vtPedidosEnViaje.getTable().getValueAt(SelectedRows[i], 0).toString())));
		}
		
		return pedidos;
	}
	
	private void PedidosEntregados(List<PedidoDTO> Pedidos) {
		for (PedidoDTO pedido:Pedidos) {
			this.mdlPedido.FinalizarPedido(pedido.getNumPedido());
		}
		
		this.CargarTabla();
	}
	
	private void PedidosNoEntregados(List<PedidoDTO> Pedidos) {
		for (PedidoDTO pedido:Pedidos) {
			this.mdlPedido.PedidoArmado(pedido.getNumPedido());
			this.mdlRepartidor.DesasignarPedido(pedido.getNumPedido());
		}
		
		this.CargarTabla();
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == this.vtPedidosEnViaje.getBtnEntregado()) {
			List<PedidoDTO> pedidos = this.PedidosSeleccionados(); 
			if (pedidos.size() > 0) {
				this.PedidosEntregados(pedidos);
			}
			else {
				JOptionPane.showMessageDialog(null, "Debe Seleccionar al Menos un Pedido", "Error Seleccion Pedido", JOptionPane.ERROR_MESSAGE);
			}
		}
		else if(arg0.getSource() == this.vtPedidosEnViaje.getBtnNoEntregado()) {
			List<PedidoDTO> pedidos = this.PedidosSeleccionados();
			if(pedidos.size() > 0) {
				this.PedidosNoEntregados(pedidos);
			}
			else {
				JOptionPane.showMessageDialog(null, "Debe Seleccionar al Menos un Pedido", "Error Seleccion Pedido", JOptionPane.ERROR_MESSAGE);
			}
		}
		else if(arg0.getSource() == this.vtPedidosEnViaje.getBtnAceptar()) {
			this.ctrPedido.Inicializar();
			this.vtPedidosEnViaje.Close();
		}
	}
}