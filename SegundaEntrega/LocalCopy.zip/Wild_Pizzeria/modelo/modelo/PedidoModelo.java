package modelo;

import java.util.List;

import dto.PedidoDTO;
import dto.ProductoEnPedidoDTO;
import dao.PedidoDAO;
import dao.ProductoEnPedidoDAO;
import daoImplementacion.PedidoImp;
import daoImplementacion.ProductoEnPedidoImp;

public class PedidoModelo {

	private PedidoDAO pedido;
	private ProductoEnPedidoDAO productos;
	
	public PedidoModelo() {
		this.pedido = new PedidoImp();
		this.productos = new ProductoEnPedidoImp();
	}
	
	public int GetNuevoNumeroPedido() {
		return this.pedido.UltimoNumPedido() + 1;
	}
	
	public void agregarPedido(PedidoDTO nuevoPedido) {
		this.pedido.CrearNuevoPedido(nuevoPedido);
	}
	
	public void cancelarPedido(int NumPedido) {
		this.pedido.CancelarPedido(NumPedido);
	}
	
	public List<PedidoDTO> GetPedidosPendientesCocina() {
		return this.pedido.pedidosPendientesCocina();
	}
	
	public List<PedidoDTO> GetPedidoSinFacturar() {
		return this.pedido.PedidoPendientesEntregar();
	}

	public void ModificarPedido(PedidoDTO Pedido) {
		this.pedido.ModificarPedido(Pedido);
	}

	public PedidoDTO GetPedido(int PedidoID) {
		return this.pedido.GetPedido(PedidoID);
	}

	public void FinalizarPedido(int NumPedido) {
		this.pedido.FacturarPedido(NumPedido);		
	}

	public void PedidoArmado(int NumPedido) {
		this.pedido.PedidoArmado(NumPedido);
	}

	/* Manda la orden a Base de Datos para que los pedidos pasados por parametro se les cambie el estado a que estan camino a ser entregador. */
	public void PedidosEnViaje(List<PedidoDTO> Pedidos) {
		this.pedido.EnviarPedidos(Pedidos);
	}

	public List<PedidoDTO> GetPedidosEnViaje() {
		return this.pedido.GetPedidosEnViaje();
	}
	
	public List<ProductoEnPedidoDTO> GetProductosEnpedido(int NumPedido) {
		return this.productos.GetProductosPara(NumPedido);
	}

	public List<ProductoEnPedidoDTO> GetProductosFaltantesElaborarCocina() {
		return this.productos.GetFaltantesElabracion();
	}
}