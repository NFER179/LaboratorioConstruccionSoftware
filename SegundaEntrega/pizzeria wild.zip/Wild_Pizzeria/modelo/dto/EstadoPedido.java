package dto;

public enum EstadoPedido {
	Pendiente,
	Preparado,
	EnVieaje,
	Entregado;
}
