package modelo;

import dao.ProductoEnPedidoDAO;
import daoImplementacion.ProductoEnPedidoImp;
import dto.ProductoEnPedidoDTO;

public class ProductoEnPedidoModelo {

	private ProductoEnPedidoDAO productos;
	
	public ProductoEnPedidoModelo() {
		this.productos = new ProductoEnPedidoImp();
	}
}
