package clasesImpresiones;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

public class ImpresionDocx {

	public void ImprimirDirecciones(String NombreArchivo, List<String> Direcciones){
		
		try {
			XWPFDocument documento = new XWPFDocument();
			XWPFParagraph parrafo = documento.createParagraph();
			XWPFRun run = parrafo.createRun();
			for(String s:Direcciones) {
				run.setText(s);
				run.addBreak();
			}
			FileOutputStream fos = new FileOutputStream(new  File(NombreArchivo + ".docx"));
			documento.write(fos);
			fos.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}