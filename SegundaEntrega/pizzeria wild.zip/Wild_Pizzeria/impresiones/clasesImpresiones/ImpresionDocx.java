package clasesImpresiones;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

public class ImpresionDocx {

	public void ImprimirDirecciones(String NombreArchivo, List<String> Direcciones){
	
		String p = "";
		for(String direccion:Direcciones){
			p = p + direccion + "\n";
		}
		
		try {
			XWPFDocument documento = new XWPFDocument();
			XWPFParagraph parrafo = documento.createParagraph();
			XWPFRun run = parrafo.createRun();
			run.setText(p);
			FileOutputStream fos = new FileOutputStream(new  File(NombreArchivo + ".doc"));
			documento.write(fos);
			fos.close();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}