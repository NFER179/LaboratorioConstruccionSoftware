/** Clase Creada por Nicolas Fernandez 30/09/2015, Vista para ingresar pedidos entregados y no entregados.**/
package vista;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;

import validacionObjetosVista.WDefaultTableModel;
import validacionObjetosVista.WTable;

public class PedidosEnViajeVista extends JDialog {
	
	private DefaultTableModel ModelTable;
	private String[] NombreColumnas = {"NumPedido"};
	private JTable table;
	private JButton btnEntregado;
	private JButton btnNoEntregado;
	private JButton btnAceptar;

	public PedidosEnViajeVista(JFrame Frame) {
		super(Frame, true);
		
		this.setTitle("Pedidos en Viaje");
		this.setBounds(100, 100, 311, 294);
		this.getContentPane().setLayout(null);
		this.setLocationRelativeTo(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 151, 197);
		this.getContentPane().add(scrollPane);

		this.ModelTable = new WDefaultTableModel(null, this.NombreColumnas);
		this.table = new WTable(this.ModelTable);
		scrollPane.setViewportView(table);
		
		this.btnEntregado = new JButton("Entregado");
		this.btnEntregado.setBounds(183, 11, 110, 23);
		this.getContentPane().add(btnEntregado);
		
		this.btnNoEntregado = new JButton("No Entregado");
		this.btnNoEntregado.setBounds(183, 45, 110, 23);
		this.getContentPane().add(btnNoEntregado);
		
		this.btnAceptar = new JButton("Aceptar");
		this.btnAceptar.setBounds(183, 226, 110, 23);
		this.getContentPane().add(btnAceptar);
	}
	
	public void Open(){
		this.setVisible(true);
	}
	
	public void Close(){
		this.setVisible(false);
	}

	public DefaultTableModel getModelTable() {
		return ModelTable;
	}

	public String[] getNombreColumnas() {
		return NombreColumnas;
	}

	public JTable getTable() {
		return table;
	}

	public JButton getBtnEntregado() {
		return btnEntregado;
	}

	public JButton getBtnNoEntregado() {
		return btnNoEntregado;
	}

	public JButton getBtnAceptar() {
		return btnAceptar;
	}
}