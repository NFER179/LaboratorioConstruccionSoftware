package controlador;

import validacionesCampos.ValidacionCampos;
import vista.ArmadoPedidoVista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;

import modelo.PedidoModelo;
import modelo.SaborModelo;

import dto.ClienteDTO;
import dto.PedidoDTO;
import dto.ProductoEnPedidoDTO;

public class ControladorArmadoPedido implements ActionListener {

	private ArmadoPedidoVista vtArmadoPedido;
	private ControladorPedido ctrPedido;
	private SaborModelo mdlSabor;
	private PedidoModelo mdlPedido;
	private ControladorPedidosCocina ctrPedidoCocina;

	public ControladorArmadoPedido(ControladorPedido ControladorPedido,
			JFrame Frame) {
		this.vtArmadoPedido = new ArmadoPedidoVista(Frame);
		this.vtArmadoPedido.getTxtNumpedido().setText("NEXT");
		this.vtArmadoPedido.getBtnBusquedaCliente().addActionListener(this);
		this.vtArmadoPedido.getBtnAgregar().addActionListener(this);
		this.vtArmadoPedido.getBtnQuitar().addActionListener(this);
		this.vtArmadoPedido.getBtnCancelar().addActionListener(this);
		this.vtArmadoPedido.getBtnArmar().addActionListener(this);
		this.vtArmadoPedido.getBtnCancelar().addActionListener(this);

		this.ctrPedido = ControladorPedido;
		this.mdlSabor = new SaborModelo();
		this.mdlPedido = new PedidoModelo();
		this.ctrPedidoCocina = ControladorPedidosCocina.GetInstancia();
	}

	public ControladorArmadoPedido(ControladorPedido ControladorPedido,
			JFrame Frame, int NumPedido) {
		this.vtArmadoPedido = new ArmadoPedidoVista(Frame);
		this.vtArmadoPedido.getTxtNumpedido().setText(
				Integer.toString(NumPedido));

		this.vtArmadoPedido.getBtnBusquedaCliente().addActionListener(this);
		this.vtArmadoPedido.getBtnAgregar().addActionListener(this);
		this.vtArmadoPedido.getBtnQuitar().addActionListener(this);
		this.vtArmadoPedido.getBtnCancelar().addActionListener(this);
		this.vtArmadoPedido.getBtnArmar().addActionListener(this);
		this.vtArmadoPedido.getBtnCancelar().addActionListener(this);

		this.ctrPedido = ControladorPedido;
		this.mdlSabor = new SaborModelo();
		this.mdlPedido = new PedidoModelo();
	}

	public void Inicializar() {
		/* ver de cambiar el pedido. */
		if (this.vtArmadoPedido.getTxtNumpedido().getText().equals("NEXT")) {
			this.CargarFecha();
			this.vtArmadoPedido.Open();
		} else {
			this.CargarPedido();
			this.vtArmadoPedido.Open();
		}
	}

	private void CargarFecha() {
		Calendar c = Calendar.getInstance();
		String fecha = "";

		fecha = fecha + c.get(Calendar.YEAR);
		fecha = fecha + "/" + c.get(Calendar.MONTH);
		fecha = fecha + "/" + c.get(Calendar.DATE);
		fecha = fecha + " " + c.get(Calendar.HOUR);
		fecha = fecha + ":" + c.get(Calendar.MINUTE);
		fecha = fecha + ":" + c.get(Calendar.SECOND);

		this.vtArmadoPedido.getTxtFecha().setText(fecha);
	}

	private void CargarPedido() {
		String textoPedido = this.vtArmadoPedido.getTxtNumpedido().getText();
		int numeroPedido = Integer.parseInt(textoPedido);
		PedidoDTO nuevoPedido = this.mdlPedido.GetPedido(numeroPedido);

		this.vtArmadoPedido.getTxtFecha().setText(nuevoPedido.getFecha_hora());
		this.vtArmadoPedido.getTxtCliente().setText(nuevoPedido.getCliente());
		this.vtArmadoPedido.getTxtCliente().setEnabled(false);
		this.vtArmadoPedido.getChckbxDelivery().setSelected(
				nuevoPedido.isDelivery());
		this.vtArmadoPedido.getTxtDireccion().setText(
				nuevoPedido.getDireccion());
		this.vtArmadoPedido.getTxtTel().setText(nuevoPedido.getTel());
		this.vtArmadoPedido.getTxtrObservacion().setText(
				nuevoPedido.getObservacion());

		/* Carga la tabla de los prductos. */
		this.vtArmadoPedido.getModelProductos().setRowCount(0);
		this.vtArmadoPedido.getModelProductos().setColumnCount(0);
		this.vtArmadoPedido.getModelProductos().setColumnIdentifiers(
				this.vtArmadoPedido.getNombreColumnas());
		for (ProductoEnPedidoDTO pp : nuevoPedido.getProductos()) {
			int PrecioUnidad = this.mdlSabor.GetPrecio(pp.getProducto(),
					pp.getSabor());
			Object[] fila = { pp.getProducto(), pp.getSabor(),
					pp.getCantidad(), Integer.toString(PrecioUnidad),
					Integer.toString(pp.getCantidad() * PrecioUnidad) };
			this.vtArmadoPedido.getModelProductos().addRow(fila);
		}
		this.vtArmadoPedido.getTblProductos().setModel(
				this.vtArmadoPedido.getModelProductos());

		this.ActualizarPrecio();
	}

	public void CargarDatosCliente(ClienteDTO Cliente) {
		this.vtArmadoPedido.getTxtCliente().setText(
				Cliente.getApellido() + " " + Cliente.getNombre());
		this.vtArmadoPedido.getTxtDireccion().setText(Cliente.getDireccion());
		this.vtArmadoPedido.getTxtTel().setText(Cliente.getTel());
	}

	private boolean ProductoAgregado(String Producto, String Sabor) {
		boolean productoAgregado = false;
		/** -> Inicio, NVR,04/10/2015 refactor */
		JTable tblProductos = this.vtArmadoPedido.getTblProductos();
		int cantidadFilas = tblProductos.getRowCount();
		for (int i = 0; i < cantidadFilas; i++) {

			String valorActual = tblProductos.getValueAt(i, 0).toString();
			boolean tieneRepetido = valorActual.equals(Producto);
			if (tieneRepetido && valorActual.equals(Sabor)) {
				productoAgregado = true;
			}
			// if (this.vtArmadoPedido.getTblProductos().getValueAt(i, 0)
			// .toString().equals(Producto))
			// if (this.vtArmadoPedido.getTblProductos().getValueAt(i, 1)
			// .toString().endsWith(Sabor)) {
			// productoAgregado = true;
			// }
			/** <- Fin, NVR,04/10/2015 refactor */
		}
		return productoAgregado;
	}

	private void SumarCantidades(String Producto, String Sabor, int cantidad) {
		/** -> Inicio, NVR,04/10/2015 refactor */

		int filas = this.vtArmadoPedido.getTblProductos().getRowCount();
		for (int i = 0; i < filas; i++) {
			decideSumarizar(Producto, Sabor, cantidad, i);
		}
		// for (int i = 0; i < tblProductos.getRowCount(); i++) {
		// if (tblProductos.getValueAt(i, 0).toString().equals(Producto))
		// if (tblProductos.getValueAt(i, 1).toString().endsWith(Sabor)) {
		// int oldPrecio = Integer.parseInt(this.vtArmadoPedido
		// .getTblProductos().getValueAt(i, 2).toString());
		// int precioFinal = oldPrecio + cantidad;
		// this.vtArmadoPedido.getTblProductos().setValueAt(
		// Integer.toString(precioFinal), i, 2);
		// }
		// }
		/** <- Fin, NVR,04/10/2015 refactor */
	}

	private void decideSumarizar(String Producto, String Sabor, int cantidad,
			int i) {
		JTable tblProductos = this.vtArmadoPedido.getTblProductos();
		String valorActual = tblProductos.getValueAt(i, 0).toString();
		boolean tieneRepetido = valorActual.equals(Producto);
		if (tieneRepetido && valorActual.endsWith(Sabor)) {
			int oldPrecio = Integer.parseInt(tblProductos.getValueAt(i, 2)
					.toString());
			String precioFinal = (oldPrecio + cantidad) + "";
			tblProductos.setValueAt(precioFinal, i, 2);
		}
	}

	public void AgregarProducto(String Producto, String Sabor, int Cantidad) {
		int PreUnid = this.mdlSabor.GetPrecio(Producto, Sabor);
		if (this.ProductoAgregado(Producto, Sabor)) {
			this.SumarCantidades(Producto, Sabor, Cantidad);
		} else {
			Object[] fila = { Producto, Sabor, Integer.toString(Cantidad),
					Integer.toString(PreUnid),
					Integer.toString(Cantidad * PreUnid) };
			this.vtArmadoPedido.getModelProductos().addRow(fila);
			this.vtArmadoPedido.getTblProductos().setModel(
					this.vtArmadoPedido.getModelProductos());
		}
		ActualizarPrecio();
	}

	private void ActualizarPrecio() {
		int precio = 0;
		/** -> Inicio, NVR,04/10/2015 refactor */
		JTable tblProducto = this.vtArmadoPedido.getTblProductos();
		int filas = tblProducto.getRowCount();
		for (int i = 0; i < filas; i++) {
			String nuevoPrecio = tblProducto.getValueAt(i, 4).toString();
			precio += Integer.parseInt(nuevoPrecio);
		}
		/** <- Fin, NVR,04/10/2015 refactor */
		// this.vtArmadoPedido.getTblProductos().getRowCount(); i++) {
		// precio = precio
		// + Integer.parseInt(this.vtArmadoPedido.getTblProductos()
		// .getValueAt(i, 4).toString());
		// }
		this.vtArmadoPedido.getTxtPrecio().setText(Integer.toString(precio));
	}

	private void QuitarProducto() {
		int[] FilasBorrar = this.vtArmadoPedido.getTblProductos()
				.getSelectedRows();
		for (int i = 0; i < FilasBorrar.length; i++) {
			this.vtArmadoPedido.getModelProductos().removeRow(FilasBorrar[i]);
		}
		this.vtArmadoPedido.getTblProductos().setModel(
				this.vtArmadoPedido.getModelProductos());
		ActualizarPrecio();
	}

	private boolean CheckDelivery() {
		if (this.vtArmadoPedido.getChckbxDelivery().isSelected())
			return true;
		else
			return false;
	}

	private void ArmarPedido() {
		if (this.vtArmadoPedido.getTxtNumpedido().getText().equals("NEXT")) {
			int NumPedido = this.mdlPedido.GetNuevoNumeroPedido();
			PedidoDTO NewPedido = new PedidoDTO(NumPedido, this.vtArmadoPedido
					.getTxtCliente().getText(), this.vtArmadoPedido
					.getTxtDireccion().getText(), this.vtArmadoPedido
					.getTxtTel().getText(),
					Integer.parseInt(this.vtArmadoPedido.getTxtPrecio()
							.getText()), this.vtArmadoPedido.getTxtFecha()
							.getText(), "Pendiente", this.vtArmadoPedido
							.getTxtrObservacion().getText(), CheckDelivery());

			for (int i = 0; i < this.vtArmadoPedido.getModelProductos()
					.getRowCount(); i++) {
				NewPedido.agregarProducto(
						this.vtArmadoPedido.getTblProductos().getValueAt(i, 0)
								.toString(),
						this.vtArmadoPedido.getTblProductos().getValueAt(i, 1)
								.toString(),
						Integer.parseInt(this.vtArmadoPedido.getTblProductos()
								.getValueAt(i, 2).toString()));
			}

			this.mdlPedido.agregarPedido(NewPedido);
		} else {
			PedidoDTO OldPedido = new PedidoDTO(
					Integer.parseInt(this.vtArmadoPedido.getTxtNumpedido()
							.getText()), this.vtArmadoPedido.getTxtCliente()
							.getText(), this.vtArmadoPedido.getTxtDireccion()
							.getText(), this.vtArmadoPedido.getTxtTel()
							.getText(), Integer.parseInt(this.vtArmadoPedido
							.getTxtPrecio().getText()), this.vtArmadoPedido
							.getTxtFecha().getText(), "Pendiente",
					this.vtArmadoPedido.getTxtrObservacion().getText(),
					CheckDelivery());

			for (int i = 0; i < this.vtArmadoPedido.getModelProductos()
					.getRowCount(); i++) {
				OldPedido.agregarProducto(
						this.vtArmadoPedido.getTblProductos().getValueAt(i, 0)
								.toString(),
						this.vtArmadoPedido.getTblProductos().getValueAt(i, 1)
								.toString(),
						Integer.parseInt(this.vtArmadoPedido.getTblProductos()
								.getValueAt(i, 2).toString()));
			}

			this.mdlPedido.ModificarPedido(OldPedido);
		}
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == this.vtArmadoPedido.getBtnBusquedaCliente()) {

			ControladorBusquedaCliente ctrBusquedaCliente = new ControladorBusquedaCliente(
					this, this.vtArmadoPedido);
			ctrBusquedaCliente.Iniciar();
		} else if (arg0.getSource() == this.vtArmadoPedido.getBtnAgregar()) {
			ControladorProductosDePedidos ctrPP = new ControladorProductosDePedidos(
					this, this.vtArmadoPedido);
			ctrPP.Iniciar();
		} else if (arg0.getSource() == this.vtArmadoPedido.getBtnQuitar()) {
			if (vtArmadoPedido.getTblProductos().getSelectedRows().length < 1)
				JOptionPane.showMessageDialog(null,
						"No hay Productos para eliminar",
						"Error Borrar Producto", JOptionPane.WARNING_MESSAGE);
			else {
				QuitarProducto();
			}
		} else if (arg0.getSource() == this.vtArmadoPedido.getBtnArmar()) {
			accionArmar();
		} else if (arg0.getSource() == this.vtArmadoPedido.getBtnCancelar()) {
			this.vtArmadoPedido.Close();
		}
	}

	private void accionArmar() {
		boolean clienteValido = !ValidacionCampos.isNullOrEmpty(vtArmadoPedido
				.getTxtCliente().getText());

		clienteValido = clienteValido
				&& !ValidacionCampos.isNullOrEmpty(vtArmadoPedido
						.getTxtDireccion().getText());

		clienteValido = clienteValido
				&& !ValidacionCampos.isNullOrEmpty(vtArmadoPedido.getTxtTel()
						.getText());
		if (clienteValido) {
			if (this.vtArmadoPedido.getModelProductos().getRowCount() > 0) {
				this.ArmarPedido();
				this.ctrPedido.RecargarTabla();
				this.vtArmadoPedido.Close();
				ctrPedidoCocina = ControladorPedidosCocina.GetInstancia();
				this.ctrPedidoCocina.RecargarTablas();
			} else {
				JOptionPane.showMessageDialog(null,
						"Debe Ingresar al Menos un Producto.");
			}
		} else {
			JOptionPane.showMessageDialog(null,
					"Ingrese un cliente nuevo o seleccione uno existente");
		}
	}
}
