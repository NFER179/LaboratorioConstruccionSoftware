package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

import modelo.RepartidorModelo;

import dto.RepartidorDTO;

import vista.BuscadorRepartidorVista;

public class ControladorBuscadorRepartidor implements ActionListener{

	private BuscadorRepartidorVista vtBuscadorRepartidor;
	private List<RepartidorDTO> lRepartidor;
	private RepartidorModelo mdlRepartidor;
	private ControladorAsignacionRepartidor ctrAsignacionRep;
	
	public ControladorBuscadorRepartidor(ControladorAsignacionRepartidor Ctr, JDialog Dialog) {
		this.vtBuscadorRepartidor = new BuscadorRepartidorVista(Dialog);
		this.vtBuscadorRepartidor.getBtnAceptar().addActionListener(this);
		this.vtBuscadorRepartidor.getBtnCancelar().addActionListener(this);
		
		this.lRepartidor = new ArrayList<RepartidorDTO>();
		this.mdlRepartidor = new RepartidorModelo();
		this.ctrAsignacionRep = Ctr;
	}
	
	public void Inicializar() {
		this.CargarTabla();
		this.vtBuscadorRepartidor.Open();
	}
	
	private void CargarTabla() {
		this.vtBuscadorRepartidor.getModelTable().setRowCount(0);
		this.vtBuscadorRepartidor.getModelTable().setColumnCount(0);
		this.vtBuscadorRepartidor.getModelTable().setColumnIdentifiers(this.vtBuscadorRepartidor.getNombreColumnas());
		this.lRepartidor = this.mdlRepartidor.GetRepartidores();
		for ( RepartidorDTO r:this.lRepartidor ) {
			Object[] fila = {Integer.toString(r.getRepartidorId()), r.getNombre()};
			this.vtBuscadorRepartidor.getModelTable().addRow(fila);
		}
		this.vtBuscadorRepartidor.getTable().setModel(this.vtBuscadorRepartidor.getModelTable());
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (this.vtBuscadorRepartidor.getTable().getSelectedRows().length==0 )
		{
		JOptionPane.showMessageDialog(null,"Seleccione un repartidor de la tabla","Error de seleccion de repartidor",JOptionPane.WARNING_MESSAGE);	
		}
		else{
		if (arg0.getSource() == this.vtBuscadorRepartidor.getBtnAceptar()) {
			if (this.vtBuscadorRepartidor.getTable().getSelectedRows().length > 0) {
				this.ctrAsignacionRep.CargarRepartidor(
					this.mdlRepartidor.GetRepartidor(
						Integer.parseInt(
							this.vtBuscadorRepartidor.getTable().getValueAt(
								this.vtBuscadorRepartidor.getTable().getSelectedRow(), 0).toString()
						)
					)
				);
			}
			this.vtBuscadorRepartidor.Close();
		}
		else if (arg0.getSource() == this.vtBuscadorRepartidor.getBtnCancelar()) {
			this.ctrAsignacionRep.Inicializar();
			this.vtBuscadorRepartidor.Close();
		}
	}
	}	
	}