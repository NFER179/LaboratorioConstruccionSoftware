/** Nicolas Daniel Fernandez, 29/09/2015 - Creacion de la clase. **/
package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import javax.swing.JFrame;

import clasesImpresiones.ImpresionDocx;

import modelo.PedidoModelo;
import modelo.RepartidorModelo;

import dto.PedidoDTO;
import dto.RepartidorDTO;

import vista.AsignacionRepartidoresVista;

public class ControladorAsignacionRepartidor implements ActionListener{

	private AsignacionRepartidoresVista vtAsignacionRepartidores;
	private ControladorPedido ctrPedido;
	private List<PedidoDTO> lPedidos;
	private RepartidorModelo mdlRepartidor;
	private PedidoModelo mdlPedido;
	
	public ControladorAsignacionRepartidor(ControladorPedido ControladorPedido, JFrame Frame, List<PedidoDTO> LPedido) {
		this.vtAsignacionRepartidores = new AsignacionRepartidoresVista(Frame);
		this.vtAsignacionRepartidores.getBtnBuscarrepartidor().addActionListener(this);
		this.vtAsignacionRepartidores.getBtnAsignar().addActionListener(this);
		this.vtAsignacionRepartidores.getBtnCancelar().addActionListener(this);
		
		this.ctrPedido = ControladorPedido;
		this.lPedidos = LPedido;
		this.mdlRepartidor = new RepartidorModelo();
		this.mdlPedido = new PedidoModelo();
	}

	public void Inicializar(){
		this.CargarTabla();
		this.vtAsignacionRepartidores.Open();
	}
	
	private void CargarTabla() {
		this.vtAsignacionRepartidores.getModelTable().setRowCount(0);
		this.vtAsignacionRepartidores.getModelTable().setColumnCount(0);
		this.vtAsignacionRepartidores.getModelTable().setColumnIdentifiers(this.vtAsignacionRepartidores.getNombreColumnas());
		for (PedidoDTO p:this.lPedidos) {
			Object[] fila = {Integer.toString(p.getNumPedido()), p.getDireccion()};
			this.vtAsignacionRepartidores.getModelTable().addRow(fila);
		}
		this.vtAsignacionRepartidores.getTable().setModel(this.vtAsignacionRepartidores.getModelTable());
	}
	
	public void CargarRepartidor(RepartidorDTO Repartidor) {
		this.vtAsignacionRepartidores.getTxtRepartidor().setText(Integer.toString(Repartidor.getRepartidorId()));
		this.vtAsignacionRepartidores.getTxtNombrerepartidor().setText(Repartidor.getApellido() + " " + Repartidor.getNombre());
	}	
	
	private List<String> ListaDireccones(){
		List<String> direcciones = new ArrayList<String>();
		for(PedidoDTO pedido:this.lPedidos){
			direcciones.add(pedido.getDireccion());
		}
		
		return direcciones;
	}
	
	private String FechaDelDia() {
		String fecha = "";
		Calendar c = Calendar.getInstance();
		fecha = fecha + c.get(Calendar.YEAR) + "-";
		fecha = fecha + c.get(Calendar.MONTH) + "-";
		fecha = fecha + c.get(Calendar.DATE) + " ";
		fecha = fecha + c.get(Calendar.HOUR) + "_";
		fecha = fecha + c.get(Calendar.MINUTE);
		
		return fecha;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (arg0.getSource() == this.vtAsignacionRepartidores.getBtnBuscarrepartidor()) {
			ControladorBuscadorRepartidor ctrBuscadorRepartidor = new ControladorBuscadorRepartidor(this, this.vtAsignacionRepartidores);
			ctrBuscadorRepartidor.Inicializar();
		}
		else if (arg0.getSource() == this.vtAsignacionRepartidores.getBtnAsignar()) {
			if(!this.vtAsignacionRepartidores.getTxtRepartidor().getText().equals(null)) {
				this.mdlRepartidor.AsignarPedidos(Integer.parseInt(this.vtAsignacionRepartidores.getTxtRepartidor().getText()),this.lPedidos);
				this.mdlPedido.PedidosEnViaje(this.lPedidos);
				this.ctrPedido.RecargarTabla();
				ImpresionDocx impresion = new ImpresionDocx();
				impresion.ImprimirDirecciones(this.FechaDelDia()+ " - " + this.vtAsignacionRepartidores.getTxtNombrerepartidor().getText() + "Direcciones", this.ListaDireccones());
				this.vtAsignacionRepartidores.Close();
			}
		}
		else if (arg0.getSource() == this.vtAsignacionRepartidores.getBtnCancelar()) {
			this.ctrPedido.Inicializar();
			this.vtAsignacionRepartidores.Close();
		}
	}
}