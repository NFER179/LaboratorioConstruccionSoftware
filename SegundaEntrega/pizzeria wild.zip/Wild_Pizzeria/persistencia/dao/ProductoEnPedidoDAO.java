package dao;

import java.util.List;

import dto.ProductoEnPedidoDTO;

public interface ProductoEnPedidoDAO {

	/* Devuelve los productos en determinado pedido. */
	public List<ProductoEnPedidoDTO> GetProductosPara(int Pedido);

	/* Trae por producto la cantidad de cada sabor que falta por elaborar */
	public List<ProductoEnPedidoDTO> GetFaltantesElabracion();
}
