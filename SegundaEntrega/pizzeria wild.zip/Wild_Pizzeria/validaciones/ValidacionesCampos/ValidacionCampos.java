package ValidacionesCampos;

public class ValidacionCampos {

	public static boolean positiveDoubleValid(String input) {
		if (doubleValid(input)) {
			double value = Double.parseDouble(input);
			return value > 0;
		}
		return false;
	}

	public static boolean positiveIntegerValid(String input) {
		if (integerValid(input)) {
			double value = Integer.parseInt(input);
			return value > 0;
		}
		return false;
	}

	public static boolean doubleValid(String input) {
		if (!isNullOrEmpty(input)) {
			try {
				Double.parseDouble(input);
				return true;
			} catch (Exception e) {
				return false;
			}
		}
		return false;
	}

	public static boolean integerValid(String input) {
		if (!isNullOrEmpty(input)) {
			try {
				Integer.parseInt(input);
				return true;
			} catch (Exception e) {
				return false;
			}
		}
		return false;
	}

	public static boolean lengthValid(String input, int maxLength) {
		if (!isNullOrEmpty(input)) {
			input = input.trim();
			return input.length() <= maxLength;
		}
		return false;
	}

	public static boolean isNullOrEmpty(String input) {
		return (input == null) ? true : input.trim().isEmpty();
	}
}
