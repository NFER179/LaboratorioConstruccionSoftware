package daoImplementacion;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import conexion.ConectorDB;

import dao.ProductoEnPedidoDAO;
import dto.ProductoEnPedidoDTO;

public class ProductoEnPedidoImp implements ProductoEnPedidoDAO {

	private ConectorDB conector;
	
	public ProductoEnPedidoImp() {
		this.conector = ConectorDB.GetInstancia();
	}
	
	@Override
	public List<ProductoEnPedidoDTO> GetProductosPara(int Pedido) {
		
		Statement stm = this.conector.GetStatement();
		String sqlString = "select * from producto_pedido where num_pedido = " + Pedido;
		ResultSet rs = null;
		List<ProductoEnPedidoDTO> productos = new ArrayList<ProductoEnPedidoDTO>();
		
		try {
			rs = stm.executeQuery(sqlString);
			
			while(rs.next()) {
				productos.add(new ProductoEnPedidoDTO(rs.getString("producto"), 
													rs.getString("sabor"), 
													rs.getInt("cantidad")));
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		finally {
			this.conector.CloseConnection();
		}
		
		return productos;
	}
	
	@Override
	public List<ProductoEnPedidoDTO> GetFaltantesElabracion() {
		
		Statement stm = this.conector.GetStatement();
		String sqlString = "select pp.producto, pp.sabor, sum(pp.cantidad) as 'cantidad' " +
							"from pedido p, producto_pedido pp " +
							"where p.num_pedido = pp.num_pedido " +
							"and p.estado = 'Pendiente' " +
							"group by pp.producto, pp.sabor";
		ResultSet rs = null;
		List<ProductoEnPedidoDTO> productos = new ArrayList<ProductoEnPedidoDTO>();
		
		try {
			rs = stm.executeQuery(sqlString);
			while(rs.next()) {
				productos.add(new ProductoEnPedidoDTO(rs.getString("producto"), rs.getString("sabor"), 
													rs.getInt("cantidad")));
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		finally {
			this.conector.CloseConnection();
		}
		
		return productos;
	}
}